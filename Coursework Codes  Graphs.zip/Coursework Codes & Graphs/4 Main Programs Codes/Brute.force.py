import numpy as np  
# Importing numpy for numerical operations like generating random numbers.

import matplotlib.pyplot as plt  
# Importing matplotlib for plotting graphs.

from scipy.spatial.distance import cdist  
# Importing cdist from scipy to calculate pairwise distances between coordinates.

def generate_coordinates(num_coordinates=10, area_size=100):
    #Generates random coordinates for coordinates within a specified area.
    np.random.seed(42)  
    # Set the random seed for reproducibility, ensuring the same results on every run.
    coordinates = np.random.rand(num_coordinates, 2) * area_size  
    # Generate random 2D coordinates (x, y) for each coordinates.
    # Rand() function generates numbers between 0 and 1, so multiplying by area_size scales them to the area defined.
    return coordinates  
    # Return the generated coordinates as a numpy array of shape (num_coordinates, 2).


def calculate_route_length(route, dist_matrix):
    #Calculate the total length of the route by summing up the pairwise distances.
    #The route is a list of coordinates indices.
    
    total_length = 0  
    # Initialize the total length of the route to 0.

    for i in range(len(route) - 1):  
        # Loop through the route except the last coordinate.
        total_length += dist_matrix[route[i], route[i + 1]]  
        # Add the distance between consecutive coordinates

    total_length += dist_matrix[route[-1], route[0]]  
    # Add the distance from the last coordinate back to the first one (depot)

    return total_length  
    # Return the total length of the route


def plot_route(coordinates, route, title="TSP Route"):
    #Plots the given route on a 2D graph with labeled axis, grid, and improved aesthetics.
    
    plt.figure(figsize=(10, 8))  
    # Create a new figure for plotting with a specific size of 10x8 inches

    plt.scatter(coordinates[:, 0], coordinates[:, 1], c='blue', s=50, label="coordinate Locations")  
    # Plot all coordinate locations as blue dots. coordinates[:, 0] is the x-coordinate, and coordinates[:, 1] is the y-coordinate
    # The label is used for the legend

    plt.plot(coordinates[route, 0], coordinates[route, 1], 'r-', linewidth=2, label="Route")  
    # Plot the route connecting coordinates in the order specified by 'route'. The route is an array of coordinate indices.
    # The color is red ('r-'), with a line width of 2px.

    plt.scatter(coordinates[0, 0], coordinates[0, 1], c='green', s=100, marker='s', label="Depot (Start/End)")  
    # Highlight the depot (starting/ending point of the route) with a green square. 's' marks it as a square shape.
    # The size of the depot is 100px. It's plotted with a label for the legend.

    plt.xlabel("X Coordinate", fontsize=12)  
    # Label the x-axis as "X Coordinate" with a font size of 12

    plt.ylabel("Y Coordinate", fontsize=12)  
    # Label the y-axis as "Y Coordinate" with a font size of 12

    plt.title(title, fontsize=16)  
    # Set the title of the plot with a specified font size

    plt.grid(True, linestyle='--', alpha=0.7)  
    # Display a grid with dashed lines and 70% opacity for better visualization

    plt.legend(loc="best")  
    # Display the legend in the best position, which matplotlib will choose automatically

    plt.show()  
    # Show the plot to the user


def simulated_annealing_tsp(coordinates, temperature=10000, cooling_rate=0.995):
    dist_matrix = cdist(coordinates, coordinates)  
    # Calculate the pairwise distance matrix between all coordinates using cdist
    # This matrix holds the distances between every pair of coordinates (including from depot to coordinates and vice versa)
    num_coordinates = len(coordinates)  
    # Get the total number of coordinates (coordinates)
    route = list(range(num_coordinates))  
    # Initialize a simple sequential route starting from the depot (coordinate 0)
    best_route = route[:]  
    # Set the initial best route to be the same as the starting route
    best_length = calculate_route_length(route, dist_matrix)  
    # Calculate the total length of the initial route

    while temperature > 1:  
        # Perform the simulated annealing algorithm while temperature is above 1
        i, j = np.random.choice(num_coordinates, 2, replace=False)  
        # Randomly select two different coordinates (i, j) to swap
        route[i], route[j] = route[j], route[i]  
        # Swap the positions of the two selected coordinates in the route=
        current_length = calculate_route_length(route, dist_matrix)  
        # Calculate the length of the new route after the swap

        
        if current_length < best_length or np.exp((best_length - current_length) / temperature) > np.random.rand():
        # If the new route length is shorter, or if the swap is accepted based on a probability function, keep the new route
            best_route = route[:] 
            # Update the best_route with the current (possibly new) route
            best_length = current_length 
            # Update the best_length with the new (possibly shorter) length
        else:
            route[i], route[j] = route[j], route[i] 
            # Undo the swap if it was not accepted, restoring the original route
        temperature *= cooling_rate  
        # Gradually reduce the temperature according to the cooling rate

    return best_route + [best_route[0]]
    # Return the best route found by the simulated annealing algorithm


# Run Simulated Annealing Algorithm
coordinates = generate_coordinates()  
# Generate random coordinate coordinates within the specified area

route = simulated_annealing_tsp(coordinates)  
# Run the simulated annealing algorithm to find the best route

plot_route(coordinates, route, "Brute Force Method")  
# Plot the found route on a 2D graph, including the coordinate locations
