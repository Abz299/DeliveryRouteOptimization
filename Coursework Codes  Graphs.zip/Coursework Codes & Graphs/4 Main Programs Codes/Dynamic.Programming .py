import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist

def generate_coordinates(coordinates=10, area_size=100): 
    # Defines a function which takes 2 arguments, which is the number of coordinates and in which area they will scattered within
    np.random.seed(42) 
    # This will hold the coordinate results to allow us to reproduce/iterate these results for different amount of coordinates
    coordinates = np.random.rand(coordinates, 2) * area_size 
    # Will generate 2 random coordinates between 0 and 1 across the field area
    return coordinates 
    # Provides our code with the random coordiantes

def plot_path(coordinates, path, title="Nearest Neighbour Algorithm via Heuristic Approach"):
    # Defines a function which takes 3 parameters into consideration, where route will be coordinates in a sorted array list
    plt.figure(figsize=(10, 7))
    # Size of grid field; tweaked to ensure all coordiantes fit within view
    plt.title(title, fontsize=14)
    # Title size
    plt.scatter(coordinates[:, 0], coordinates[:, 1], c='black', s=60, label="Coordinates")
    # Will extract all x and y coordinates and present them as black circles with size 30
    plt.plot(coordinates[path, 0], coordinates[path, 1], 'b-', linewidth=3, label="Path")
    # Will order and present x and y coordinates in order of route processing, a certain program entials, will present as a blue line
    plt.scatter(coordinates[0, 0], coordinates[0, 1], c='purple', s=100, marker='s', label="Depot (Start & End point)")
    # Marks the starting point (Depot), in thr form of a purple dot.
    plt.legend(loc="best")
    # Code box to reperesent all legends/labels used
    plt.show()
    # Presents final figure

from functools import lru_cache
# This Import allows for memory retention of previously visited coordinates

def closest_point(coordinates):
    # Defining our function for this following method of working out most effecient path
    n = len(coordinates)
    # Gives the amount of coordinates a magnitude
    dist_matrix = cdist(coordinates, coordinates)
    # Computes distance between 2 coordinates

    @lru_cache(None)
    #Stores specific coordinate visited
    
    def visit(visited, last):
        # Embedded function which will responsible for computing optimal path from the last visited point.
        if visited == (1 << n) - 1:
             # A bitmask expression, such that when n is 1, it will mean all coordinates have been visited.
            return dist_matrix[last][0], [0]
        # If all points are visited, the path will return to depot
        min_travel, min_path = float('inf'), []
        # The path is given an intial empty list and the minimum travel per iteration is stored as infinity 
        
        for i in range(n):
            if not visited & (1 << i):
                # If coodinate i is not visted (1 << i) == 0 and loop will continue, as when n=1, is when all coordinates have been visited
                travel, path = visit(visited | (1 << i), i)
                # Both travel and path are updated, via marking that specific i as visited
                travel += dist_matrix[last][i]
                # Distance matrix updated
                if travel < min_travel:
                    min_travel, min_path = travel, path + [i]
                # If this spsecifc new travel is smaller than the previous minimum travel, both path and travel directories are updated

        return min_travel, min_path

    total_travel, path = visit(1, 0)
    # Given minimal is found visted we set total_travel to 1 and reset that specific coordinate to 0
    path.reverse()
    # At the end of this program, given paths are added onto each time, the sequence must be reveresed 
    path = [0] + path
    # Ensures the journey starts of at the depot
    return path


coordinates = generate_coordinates()
# Applying our coordinate generating function
path = closest_point(coordinates)
# Applying Function specific to this method, to compute a path for the system
plot_path(coordinates, path, title="Dynamic Programming TSP Path")
# Applying our Graphical generating function