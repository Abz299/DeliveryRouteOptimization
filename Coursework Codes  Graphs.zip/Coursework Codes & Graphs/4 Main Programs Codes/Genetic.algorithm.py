import random 
# Imports the module name random for random number generation.

import numpy as np 
# Imports numpy for numerical operations.

from scipy.spatial.distance import cdist 
# Imports cdist to compute a distance matrix between coordinates.

import matplotlib.pyplot as plt
# Imports a submodule called pyplot of the matplotlib library in Python which enables it to plot graphs.

def generate_coordinates(coordinates=10, area_size=100):
    # Generates random coordinates within a given area size.
    
    np.random.seed(42) 
    # sets the random number generator's seed in the numpy library to a fixed value, ensuring the same random numbers in each run.
    
    coordinates = np.random.rand(coordinates, 2) * area_size 
    # Generates random coordinates in a 2D space within the specified area.
    
    return coordinates 
    # Return the generated coordinates.

def plot_path(coordinates, path, title="Genetic Algorithm TSP Route"):
    # Plots the route given by a set of coordinates and the path order.
    
    plt.figure(figsize=(10, 7))  
    # Sets the figure size for the plot and the parameters of the size which is 10X7 inches.
    
    plt.title(title, fontsize=14)  
    # Sets the plot title with a font size of 14
    
    plt.scatter(coordinates[:, 0], coordinates[:, 1], c='black', s=60, label="Coordinates")  
    # Plots customer locations as black dots by selecting each coloumns and rows.
    
    closed_path = np.append(path, path[0])
    # Append the first city to the end of the path to close the loop
    
    plt.plot(coordinates[path, 0], coordinates[path, 1], 'b-', linewidth=3, label="Path")  
    # Draws the path using a blue line connecting the coordinates.
    
    plt.scatter(coordinates[0, 0], coordinates[0, 1], c='purple', s=100, marker='s', label="Depot (Start & End point)")  
    # Highlights the start/end point with a purple square.
    
    plt.legend(loc="upper right")
    # Adds a legend on the top right to the plot  
    
    plt.show()  
    # Display the plot.
    
import random

def calculate_path_length(route, dist_matrix):
#  calculates the total length of a route by summing the distances between consecutive cities in the route,
#  including the distance from the last city back to the first to complete the loop
    return sum(dist_matrix[route[i], route[i + 1]] for i in range(len(route) - 1)) + dist_matrix[route[-1], route[0]]
    # Calculate the total distance by summing up distances between consecutive cities.
    # Include the distance from the last city back to the first to complete the loop.

def genetic_algorithm_tsp(coordinates, population_size=100, generations=500, mutation_rate=0.1):
    # Compute the distance matrix between all customer locations.
    # Each entry dist_matrix[i, j] represents the distance between customer i and customer j.
    dist_matrix = cdist(coordinates, coordinates)  
    # Compute the pairwise distance matrix for the customer locations.
    num_coordinates = len(coordinates)  
    # Determine the number of customers (cities) to visit.
    population = [random.sample(range(num_coordinates), num_coordinates) for _ in range(population_size)]  
    # Initialize the population with random routes (permutations of customer indices)
    best_path = min(population, key=lambda path: calculate_path_length(path, dist_matrix))  
    # Find the best initial path based on the route length.
    best_length = calculate_path_length(best_path, dist_matrix)  
    # Calculate the length of the best initial path.

    for generation in range(generations):
        # Iterate through the specified number of generations to evolve the solution.
        new_population = []  
        # Generate a new population for the next generation.

        for _ in range(population_size // 2):
         # Create new individuals (children) using crossover from two parents.
            parent1, parent2 = random.sample(population, 2)  
            # Randomly select two parents from the current population.
            child = parent1[:num_coordinates // 2] + [c for c in parent2 if c not in parent1[:num_coordinates // 2]]
            # Perform crossover: take the first half of parent1 and fill with remaining cities from parent2.
        
            if random.random() < mutation_rate:
            # Perform mutation with a certain probability to introduce variation.
                a, b = random.sample(range(len(child)), 2)  
                # Randomly select two indices in the child's route.
                child[a], child[b] = child[b], child[a]  
                # Swap the selected cities in the route.
            new_population.append(child)  
            # Add the mutated child to the new population.
        population = new_population  
        # Replace the old population with the newly generated offspring.
        current_best = min(population, key=lambda route: calculate_path_length(route, dist_matrix))  
        # Find the best route in the current generation using the calculate_route_length function.
        current_length = calculate_path_length(current_best, dist_matrix)  
        # Calculate the length of the current best route.
        
        if current_length < best_length:
        # If the current best route is shorter than the previous best, update the best route and its length.
            best_length = current_length  
            # Update the best known length.
            best_path = current_best  
            # Update the best known path.

    return best_path + [best_path[0]]  
    # Return the best path found after all generations.


coordinates = generate_coordinates()  
# Generate random customer coordinates.
path = genetic_algorithm_tsp(coordinates)  
# Run the Genetic Algorithm to solve the TSP.
plot_path(coordinates, path, "Genetic Algorithm TSP Route")  
# Plot the resulting best route.
