import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist

# Defines a function which takes 2 arguments, which is the number of coordinates and in which area they will scattered within
def generate_coordinates(coordinates, area_size): 
    #Error handling to ensure only ints are inputted into the func
    if isinstance(coordinates, int):
        # This will hold the coordinate results to allow us to reproduce/iterate these results for different amount of coordinates
        np.random.seed(42)
        # Will generate 2 random coordinates between 0 and 1 across the field area
        coordinates = np.random.rand(coordinates, 2) * area_size 
        # Provides our code with the random coordiantes
        return coordinates 
    else:
        raise ValueError('An non int inserted into argument 1')
    
# Defines a function which takes 3 parameters into consideration, where route will be coordinates in a sorted array list
def plot_path(coordinates, count, path_weight, path, title="Nearest Neighbour Algorithm via Heuristic Approach"):
    
    # Size of grid field; tweaked to ensure all coordiantes fit within view
    plt.figure(figsize=(10, 7))
    # Title size
    plt.title(title, fontsize=14)
    # Will extract all x and y coordinates and present them as black circles with size 30
    plt.scatter(coordinates[:, 0], coordinates[:, 1], c='black', s=60, label="Coordinates")
    # Will order and present x and y coordinates in order of route processing, a certain program entials, will present as a blue line
    plt.plot(coordinates[path, 0], coordinates[path, 1], 'b-', linewidth=3, label="Path")
    # Marks the starting point (Depot), in thr form of a purple dot.
    plt.scatter(coordinates[0, 0], coordinates[0, 1], c='purple', s=100, marker='s', label="Depot (Start & End point)")
    # Code box to reperesent all legends/labels used
    plt.legend(loc="best")
    #Shows the Run Time and Path Weight of the algorithm
    plt.text(85, 100,"Run Time:"+ str(count), color ='black', fontsize = 10)
    plt.text(85, 96,"Path weight:"+str(path_weight), color ='black', fontsize = 10)
    # Presents final figure
    plt.show()

    # Defining function called coordinates
def closest_point(coordinates):
    # The len function will store all the coordinates as collection_coordinates
    collection_coordinates = len(coordinates)
    # Via Cdist, this will compute distance between 2 coordinates in matrix form pairs 
    distance_pair = cdist(coordinates, coordinates)
    # Repersent start point AKA depot
    path = [0]  
    # Ensures the coordinates aren't visted more than once by putting them in a set
    visited = {0}
    #Tally of run time, a combination of finding the nearest neighbour and comparing one to all others.  
    complexity_count = 1

        # A loop which will only end once all coordinates are visited, where len(path) will be the coordinate being assessed at a point
    while len(path) < collection_coordinates:
        
        # Will store the last coordinate
        last = path[-1]
        # Embedded function which will iterate all coordinates previously executed, with condition of not comparing coordinates already visited 
        # This embedded function will produce 2 forms of data; Distance(to specific unvisited coordinate) and index(location in the column array of that coordinate)
        # [1] Will extract index from the 2nd term
        nearest = min((distance, index) for index, distance in enumerate(distance_pair[last]) if index not in visited)[1]
        
        #A loop to keep count of the run time
        for index in enumerate(distance_pair[last]):
            if index not in visited:
                #+1 is used to account for the cdist func
                complexity_count += 1
        
        
            
        # Adds to the list of visited coordinates
        visited.add(nearest)
        # Adds to the route/path 
        path.append(nearest)

    path.append(0)  
    
    #Cal the path weight, 1 is used as an intializer instead of 0 for safety (ie avoid dividing by zero errors)
    path_weight = 1
    for weight in path:
        path_weight += weight
    
    
    
    # Ensures the last point is the depot, 1 is remove from the complexity_count and path_weight since we intialized their values with 1 instead of 0
    return complexity_count-1, path_weight-1, path


# Applying our coordinate generating function
coordinates = generate_coordinates(150, 100)
# Applying Function specific to this method, to compute a path for the system
complexity_count, path_weight, path = closest_point(coordinates)
# Applying our Graphical generating function
plot_path(coordinates, complexity_count, path_weight, path, title="Nearest Neighbour Algorithm via Heuristic Approach")