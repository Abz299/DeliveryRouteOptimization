import numpy as np  
# Importing numpy for numerical operations like generating random numbers.

import matplotlib.pyplot as plt  
# Importing matplotlib for plotting graphs.

from scipy.spatial.distance import cdist  
# Importing cdist from scipy to calculate pairwise distances between coordinates.

# Fixed coordinates provided by the user
coordinates = np.array([
    [37.45, 95.07],  # Coordinate 1
    [73.2, 59.87],   # Coordinate 2
    [15.6, 15.6],    # Coordinate 3
    [5.06, 86.62],   # Coordinate 4
    [60.11, 70.81],  # Coordinate 5
    [2.06, 96.99],   # Coordinate 6
    [83.24, 21.23],  # Coordinate 7
    [18.18, 18.34],  # Coordinate 8
    [30.42, 52.48],  # Coordinate 9
    [43.19, 29.12]   # Coordinate 10
])

def calculate_route_length(route, dist_matrix):
    # Calculate the total length of the route by summing up the pairwise distances.
    total_length = 0
    for i in range(len(route) - 1):  # Loop through the route except the last coordinate.
        total_length += dist_matrix[route[i], route[i + 1]]  # Add the distance between consecutive coordinates
    total_length += dist_matrix[route[-1], route[0]]  # Add the distance from the last coordinate back to the first one (depot)
    return total_length  # Return the total length of the route


def plot_route(coordinates, route, title="TSP Route"):
    # Plots the given route on a 2D graph with labeled axis, grid, and improved aesthetics.
    plt.figure(figsize=(10, 8))  # Create a new figure for plotting with a specific size of 10x8 inches
    plt.scatter(coordinates[:, 0], coordinates[:, 1], c='blue', s=50, label="coordinate Locations")  
    # Plot all coordinate locations as blue dots.
    plt.plot(coordinates[route, 0], coordinates[route, 1], 'r-', linewidth=2, label="Route")  
    # Plot the route connecting coordinates in the order specified by 'route'. 
    plt.scatter(coordinates[0, 0], coordinates[0, 1], c='green', s=100, marker='s', label="Depot (Start/End)")  
    # Highlight the depot (starting/ending point of the route) with a green square.
    plt.xlabel("X Coordinate", fontsize=12)  
    plt.ylabel("Y Coordinate", fontsize=12)  
    plt.title(title, fontsize=16)  
    plt.grid(True, linestyle='--', alpha=0.7)  
    plt.legend(loc="best")  
    plt.show()  # Show the plot to the user


def simulated_annealing_tsp(coordinates, temperature=10000, cooling_rate=0.995):
    dist_matrix = cdist(coordinates, coordinates)  # Calculate the pairwise distance matrix
    num_coordinates = len(coordinates)  # Get the total number of coordinates
    route = list(range(num_coordinates))  # Initialize a simple sequential route starting from the depot (coordinate 0)
    best_route = route[:]  # Set the initial best route to be the same as the starting route
    best_length = calculate_route_length(route, dist_matrix)  # Calculate the total length of the initial route

    while temperature > 1:  # Perform the simulated annealing algorithm while temperature is above 1
        i, j = np.random.choice(num_coordinates, 2, replace=False)  # Randomly select two different coordinates (i, j) to swap
        route[i], route[j] = route[j], route[i]  # Swap the positions of the two selected coordinates in the route
        current_length = calculate_route_length(route, dist_matrix)  # Calculate the length of the new route after the swap

        # If the new route length is shorter, or if the swap is accepted based on a probability function, keep the new route
        if current_length < best_length or np.exp((best_length - current_length) / temperature) > np.random.rand():
            best_route = route[:]  # Update the best_route with the current (possibly new) route
            best_length = current_length  # Update the best_length with the new (possibly shorter) length
        else:
            route[i], route[j] = route[j], route[i]  # Undo the swap if it was not accepted, restoring the original route
        
        temperature *= cooling_rate  # Gradually reduce the temperature according to the cooling rate

    # Print the best route (path) as a list of city indices
    print(f"Best route (path): {best_route}")
    
    return best_route + [best_route[0]]  # Return the best route found by the simulated annealing algorithm


# Run Simulated Annealing Algorithm
route = simulated_annealing_tsp(coordinates)  # Run the simulated annealing algorithm to find the best route
plot_route(coordinates, route, "Method Brute Force")  # Plot the found route on a 2D graph
