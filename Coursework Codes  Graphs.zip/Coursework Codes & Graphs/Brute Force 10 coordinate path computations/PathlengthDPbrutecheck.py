import numpy as np
from scipy.spatial.distance import cdist

# Coordinates of the cities
coordinates = np.array([
    [0, 0], [20, 3], [50, 10], [60, 60], [90, 20], [10, 90], 
    [25, 55], [80, 90], [5, 70], [55, 40]
])

# Calculate the pairwise distance matrix between all points
dist_matrix = cdist(coordinates, coordinates)

# Function to calculate the total path length
def calculate_route_length(route, dist_matrix):
    total_length = 0
    for i in range(len(route) - 1):
        total_length += dist_matrix[route[i], route[i + 1]]
    total_length += dist_matrix[route[-1], route[0]]  # Return to the starting point
    return total_length

# Define the two routes
route_1 = [8, 6, 0, 1, 2, 4, 9, 3, 7, 5]  # Route 1
route_2 = [0, 1, 6, 9, 3, 4, 7, 8, 5, 2]  # Route 2

# Calculate the path lengths for the routes
path_length_1 = calculate_route_length(route_1, dist_matrix)
path_length_2 = calculate_route_length(route_2, dist_matrix)

# Print the path lengths
print(f"Path length for Route 1 [8, 6, 0, 1, 2, 4, 9, 3, 7, 5]: {path_length_1:.2f}")
print(f"Path length for Route 2 [0, 1, 6, 9, 3, 4, 7, 8, 5, 2]: {path_length_2:.2f}")
