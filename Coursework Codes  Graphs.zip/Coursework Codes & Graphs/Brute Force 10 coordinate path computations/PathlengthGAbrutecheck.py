import numpy as np
from scipy.spatial.distance import cdist

# Coordinates
coordinates = np.array([
    [37.45, 95.07],  # Coordinate 1
    [73.20, 59.87],  # Coordinate 2
    [15.60, 15.60],  # Coordinate 3
    [5.81, 86.62],   # Coordinate 4
    [60.11, 70.81],  # Coordinate 5
    [2.06, 96.99],   # Coordinate 6
    [83.24, 21.23],  # Coordinate 7
    [18.18, 18.34],  # Coordinate 8
    [30.42, 52.48],  # Coordinate 9
    [43.19, 29.12]   # Coordinate 10
])

# Function to calculate total path length
def calculate_route_length(route, dist_matrix):
    total_length = 0
    for i in range(len(route) - 1):
        total_length += dist_matrix[route[i], route[i + 1]]  # Add the distance between consecutive coordinates
    total_length += dist_matrix[route[-1], route[0]]  # Add the distance from the last coordinate back to the first one
    return total_length

# Calculate pairwise distance matrix between all coordinates
dist_matrix = cdist(coordinates, coordinates)

# Given Routes
route_1 = [5, 3, 8, 7, 2, 9, 6, 1, 4, 0]  # Route 1
route_2 = [0, 5, 4, 3, 7, 9, 1, 6, 8, 2]  # Route 2

# Calculate the path lengths
path_length_1 = calculate_route_length(route_1, dist_matrix)
path_length_2 = calculate_route_length(route_2, dist_matrix)

# Output the results
print(f"Path Length for Route 1: {path_length_1:.2f}")
print(f"Path Length for Route 2: {path_length_2:.2f}")
