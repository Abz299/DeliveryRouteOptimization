import numpy as np
from scipy.spatial.distance import cdist

# Coordinates of the cities
coordinates = np.array([
    [37.45, 95.07], [73.2, 59.87], [15.6, 15.6], [5.06, 86.62], 
    [60.11, 70.81], [2.06, 96.99], [83.24, 21.23], [18.18, 18.34], 
    [30.42, 52.48], [43.19, 29.12]
])

# Calculate the pairwise distance matrix between all points
dist_matrix = cdist(coordinates, coordinates)

# Function to calculate the total path length
def calculate_route_length(route, dist_matrix):
    total_length = 0
    for i in range(len(route) - 1):
        total_length += dist_matrix[route[i], route[i + 1]]
    total_length += dist_matrix[route[-1], route[0]]  # Return to the starting point
    return total_length

# Define the two routes
route_1 = [7, 9, 6, 1, 4, 0, 5, 3, 8, 2]  # Route 1
route_2 = [0, 3, 5, 8, 9, 1, 4, 2, 7, 6, 0]  # Route 2

# Calculate the path lengths for the routes
path_length_1 = calculate_route_length(route_1, dist_matrix)
path_length_2 = calculate_route_length(route_2, dist_matrix)

# Print the path lengths
print(f"Path length for Route 1 [7, 9, 6, 1, 4, 0, 5, 3, 8, 2]: {path_length_1:.2f}")
print(f"Path length for Route 2 [0, 3, 5, 8, 9, 1, 4, 2, 7, 6, 0]: {path_length_2:.2f}")
