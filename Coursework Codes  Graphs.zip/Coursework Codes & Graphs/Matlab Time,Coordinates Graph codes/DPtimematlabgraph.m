% Data from the table
number_of_coordinates = [10, 15, 16, 17, 18, 19, 20];
executed_time = [0.0137, 0.6655, 1.4701, 3.3013, 7.6221, 18.0212, 44.4227];

% Plotting the graph
figure;
plot(number_of_coordinates, executed_time, '-o', 'LineWidth', 2);
title('Run Time vs. Number of Coordinates');
xlabel('Number of Coordinates');
ylabel('Executed Time (seconds)');
grid on;
