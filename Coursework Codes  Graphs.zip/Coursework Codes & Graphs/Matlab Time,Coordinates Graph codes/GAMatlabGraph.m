coordinates = [10, 15, 20, 25, 30, 35, 40, 45, 50];
execution_time = [0.1418, 0.1873, 0.2421, 0.3371, 0.3706, 0.4381, 0.5154, 0.5883, 0.6799];
figure;
plot(coordinates, execution_time, '-o', 'LineWidth', 1.5, 'MarkerSize', 6);
xlabel('Number of Coordinates');
ylabel('Executed Time');
title('Run Time for Code GA');
grid on;
