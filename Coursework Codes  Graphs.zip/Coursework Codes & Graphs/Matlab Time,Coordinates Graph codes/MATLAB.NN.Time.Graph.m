coordinates = [10, 15, 20, 25, 30, 35, 40, 45, 50];
execution_time = [0.0026, 0.0014, 0.0016, 0.0022, 0.0012, 0.0013, 0.0018, 0.0020, 0.0020];
figure;
plot(coordinates, execution_time, '-o', 'LineWidth', 1.5, 'MarkerSize', 6);
xlabel('Number of Coordinates');
ylabel('Executed Time');
title('Run Time for Code NN');
grid on;
