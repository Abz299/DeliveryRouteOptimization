import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist
import time  # Import time module to measure execution time
from functools import lru_cache

def generate_coordinates(coordinates=20, area_size=100): 
    np.random.seed(42) 
    coordinates = np.random.rand(coordinates, 2) * area_size 
    return coordinates 

def plot_path(coordinates, path, title="Nearest Neighbour Algorithm via Heuristic Approach"):
    plt.figure(figsize=(10, 7))
    plt.title(title, fontsize=14)
    plt.scatter(coordinates[:, 0], coordinates[:, 1], c='black', s=60, label="Coordinates")
    plt.plot(coordinates[path, 0], coordinates[path, 1], 'b-', linewidth=3, label="Path")
    plt.scatter(coordinates[0, 0], coordinates[0, 1], c='purple', s=100, marker='s', label="Depot (Start & End point)")
    plt.legend(loc="best")
    plt.show()

def closest_point(coordinates):
    n = len(coordinates)
    dist_matrix = cdist(coordinates, coordinates)

    @lru_cache(None)
    def visit(visited, last):
        if visited == (1 << n) - 1:
            return dist_matrix[last][0], [0]

        min_travel, min_path = float('inf'), []

        for i in range(n):
            if not visited & (1 << i):
                travel, path = visit(visited | (1 << i), i)
                travel += dist_matrix[last][i]
                if travel < min_travel:
                    min_travel, min_path = travel, path + [i]

        return min_travel, min_path

    total_travel, path = visit(1, 0)
    path.reverse()
    path = [0] + path
    return path

# Start measuring execution time
start_time = time.time()

coordinates = generate_coordinates()  # Generate random coordinates
path = closest_point(coordinates)  # Run the Dynamic Programming TSP algorithm
print(f"Execution time: {time.time() - start_time:.4f} seconds")  # Print execution time

plot_path(coordinates, path, title="Dynamic Programming TSP Path")  # Plot the path
