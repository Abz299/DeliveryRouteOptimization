import random 
import numpy as np 
from scipy.spatial.distance import cdist 
import matplotlib.pyplot as plt
import time  # Import time to measure execution time

def generate_coordinates(coordinates=50, area_size=100):
    np.random.seed(42)
    coordinates = np.random.rand(coordinates, 2) * area_size
    return coordinates 

def plot_path(coordinates, path, title="Genetic Algorithm TSP Route"):
    plt.figure(figsize=(10, 7))  
    plt.title(title, fontsize=14)  
    plt.scatter(coordinates[:, 0], coordinates[:, 1], c='black', s=60, label="Coordinates")  
    closed_path = np.append(path, path[0])
    plt.plot(coordinates[path, 0], coordinates[path, 1], 'b-', linewidth=3, label="Path")  
    plt.scatter(coordinates[0, 0], coordinates[0, 1], c='purple', s=100, marker='s', label="Depot (Start & End point)")  
    plt.legend(loc="upper right")
    plt.show()

def calculate_path_length(route, dist_matrix):
    return sum(dist_matrix[route[i], route[i + 1]] for i in range(len(route) - 1)) + dist_matrix[route[-1], route[0]]

def genetic_algorithm_tsp(coordinates, population_size=100, generations=500, mutation_rate=0.1):
    dist_matrix = cdist(coordinates, coordinates)  
    num_coordinates = len(coordinates)  
    population = [random.sample(range(num_coordinates), num_coordinates) for _ in range(population_size)]  
    best_path = min(population, key=lambda path: calculate_path_length(path, dist_matrix))  
    best_length = calculate_path_length(best_path, dist_matrix)  

    for generation in range(generations):
        new_population = []  
        for _ in range(population_size // 2):
            parent1, parent2 = random.sample(population, 2)  
            child = parent1[:num_coordinates // 2] + [c for c in parent2 if c not in parent1[:num_coordinates // 2]]
            if random.random() < mutation_rate:
                a, b = random.sample(range(len(child)), 2)  
                child[a], child[b] = child[b], child[a]  
            new_population.append(child)  
        population = new_population  
        current_best = min(population, key=lambda route: calculate_path_length(route, dist_matrix))  
        current_length = calculate_path_length(current_best, dist_matrix)  
        if current_length < best_length:
            best_length = current_length  
            best_path = current_best  

    return best_path + [best_path[0]]  

# Start measuring execution time
start_time = time.time()
coordinates = generate_coordinates()  
path = genetic_algorithm_tsp(coordinates)  
print(f"Execution time: {time.time() - start_time:.4f} seconds")  # Print execution time
plot_path(coordinates, path, "Genetic Algorithm TSP Route")
